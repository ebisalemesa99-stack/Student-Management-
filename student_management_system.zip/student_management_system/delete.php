<?php
require_once __DIR__ . '/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if ($id) { $stmt=$pdo->prepare('DELETE FROM students WHERE id=?'); $stmt->execute([$id]); }
header('Location: index.php?message=' . urlencode('Student deleted if the record existed.')); exit;
