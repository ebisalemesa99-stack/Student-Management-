<?php
require_once __DIR__ . '/config.php';
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id LIKE ? OR full_name LIKE ? OR department LIKE ? ORDER BY id DESC");
    $term = "%$search%";
    $stmt->execute([$term, $term, $term]);
    $students = $stmt->fetchAll();
} else {
    $students = $pdo->query("SELECT * FROM students ORDER BY id DESC")->fetchAll();
}
$total = (int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$departments = (int)$pdo->query("SELECT COUNT(DISTINCT department) FROM students")->fetchColumn();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Management System</title><link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar"><div class="brand"><span class="brand-mark">S</span><div><strong>StudentHub</strong><small>Student Management System</small></div></div><span class="admin-pill">Admin workspace</span></header>
<main class="container">
  <section class="welcome"><div><p class="eyebrow">OVERVIEW</p><h1>Student management</h1><p class="muted">Manage student records in one simple place.</p></div><a class="btn primary" href="add.php">＋ Add student</a></section>
  <section class="stats"><article class="stat-card"><span class="stat-icon">♙</span><div><p>Total students</p><strong><?= $total ?></strong></div></article><article class="stat-card"><span class="stat-icon violet">▦</span><div><p>Departments</p><strong><?= $departments ?></strong></div></article><article class="stat-card"><span class="stat-icon green">✓</span><div><p>System status</p><strong class="status">Ready</strong></div></article></section>
  <?php if (isset($_GET['message'])): ?><div class="notice"><?= htmlspecialchars($_GET['message']) ?></div><?php endif; ?>
  <section class="panel"><div class="panel-head"><div><h2>Student records</h2><p class="muted">Search, edit, or remove a student.</p></div><form class="search" method="get"><input name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search name, ID, department"><button class="btn secondary">Search</button></form></div>
  <div class="table-wrap"><table><thead><tr><th>Student ID</th><th>Full name</th><th>Department</th><th>Year</th><th>Email</th><th>Actions</th></tr></thead><tbody>
  <?php if (!$students): ?><tr><td colspan="6" class="empty">No students found. Add your first student.</td></tr><?php endif; ?>
  <?php foreach ($students as $s): ?><tr><td><span class="student-id"><?= htmlspecialchars($s['student_id']) ?></span></td><td><strong><?= htmlspecialchars($s['full_name']) ?></strong></td><td><?= htmlspecialchars($s['department']) ?></td><td><?= htmlspecialchars($s['year_of_study']) ?></td><td><?= htmlspecialchars($s['email'] ?? '') ?></td><td class="actions"><a href="edit.php?id=<?= (int)$s['id'] ?>">Edit</a><form method="post" action="delete.php" class="inline delete-form"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="link danger" type="submit">Delete</button></form></td></tr><?php endforeach; ?>
  </tbody></table></div><p class="table-foot">Showing <?= count($students) ?> record(s)</p></section>
  <footer>StudentHub · Learning project built with HTML, CSS, JavaScript, PHP and MySQL</footer>
</main><script src="script.js"></script></body></html>