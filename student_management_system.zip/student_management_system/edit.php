<?php
require_once __DIR__ . '/config.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: index.php'); exit; }
$stmt = $pdo->prepare('SELECT * FROM students WHERE id=?'); $stmt->execute([$id]); $student = $stmt->fetch();
if (!$student) { header('Location: index.php?message=' . urlencode('Student not found.')); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = ['student_id','full_name','department','year_of_study','email','phone'];
    foreach ($fields as $field) $student[$field] = trim($_POST[$field] ?? '');
    if ($student['student_id']==='' || $student['full_name']==='' || $student['department']==='') $errors[]='Student ID, full name, and department are required.';
    if (!in_array($student['year_of_study'], ['1','2','3','4','5','6'], true)) $errors[]='Choose a valid year of study.';
    if ($student['email']!=='' && !filter_var($student['email'], FILTER_VALIDATE_EMAIL)) $errors[]='Enter a valid email address.';
    if (!$errors) {
        try {
            $q=$pdo->prepare('UPDATE students SET student_id=?, full_name=?, department=?, year_of_study=?, email=?, phone=? WHERE id=?');
            $q->execute([$student['student_id'],$student['full_name'],$student['department'],$student['year_of_study'],$student['email']?:null,$student['phone']?:null,$id]);
            header('Location: index.php?message='.urlencode('Student updated successfully.')); exit;
        } catch (PDOException $e) { $errors[]='That student ID may already exist. Check the ID and try again.'; }
    }
}
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Edit student · StudentHub</title><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand brand-link" href="index.php"><span class="brand-mark">S</span><div><strong>StudentHub</strong><small>Student Management System</small></div></a><a class="btn secondary" href="index.php">← Back</a></header>
<main class="form-container"><p class="eyebrow">STUDENT RECORD</p><h1>Edit student</h1><p class="muted">Update the record and save your changes.</p>
<?php if ($errors): ?><div class="error-box"><?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?></div><?php endif; ?>
<form method="post" class="panel form-panel" id="student-form">
<label>Student ID <span>*</span><input name="student_id" required maxlength="40" value="<?= h($student['student_id']) ?>"></label>
<label>Full name <span>*</span><input name="full_name" required maxlength="120" value="<?= h($student['full_name']) ?>"></label>
<label>Department <span>*</span><input name="department" required maxlength="100" value="<?= h($student['department']) ?>"></label>
<label>Year of study <span>*</span><select name="year_of_study"><?php for($i=1;$i<=6;$i++): ?><option value="<?= $i ?>" <?= (string)$student['year_of_study']==(string)$i?'selected':'' ?>>Year <?= $i ?></option><?php endfor; ?></select></label>
<label>Email <input type="email" name="email" maxlength="160" value="<?= h($student['email']) ?>"></label>
<label>Phone <input name="phone" maxlength="30" value="<?= h($student['phone']) ?>"></label>
<div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary" type="submit">Update student</button></div></form></main><script src="script.js"></script></body></html>