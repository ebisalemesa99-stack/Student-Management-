STUDENTHUB - STUDENT MANAGEMENT SYSTEM
======================================

Features
- Responsive dashboard
- Add, view, search, edit and delete student records
- MySQL database
- PHP PDO prepared statements
- HTML, CSS and JavaScript
- Mobile-friendly layout

FILES
- index.php       Dashboard and student list
- add.php         Add a student
- edit.php        Edit a student
- delete.php      Delete a student
- config.php      Database connection settings
- database.sql    Database and table creation script
- style.css       Responsive visual design
- script.js       Browser interactions

RUN LOCALLY WITH XAMPP
1. Install XAMPP from https://www.apachefriends.org/
2. Copy the whole student_management_system folder to:
   C:\xampp\htdocs\student_management_system
3. Open XAMPP Control Panel. Start Apache and MySQL.
4. Open http://localhost/phpmyadmin
5. Choose Import, select database.sql, then click Import/Go.
   Alternatively, open the SQL tab and run the contents of database.sql.
6. Open http://localhost/student_management_system

IF XAMPP DOES NOT START
This app cannot connect to its local MySQL database until the MySQL service is running.
Do not delete the data folder. Resolve the XAMPP port/service error first, or use hosting.

PUBLISH ONLINE FOR A PHONE LINK
1. Choose a host that supports PHP and MySQL (for example, InfinityFree or another PHP host).
2. Create a MySQL database in the hosting dashboard.
3. Import database.sql using the host's phpMyAdmin. If the host does not allow CREATE DATABASE,
   remove the first two lines (CREATE DATABASE and USE) and import the remaining table SQL
   into the database you created in the hosting dashboard.
4. Upload the PHP/CSS/JS files (not README.txt if you prefer) into the host's web root
   such as htdocs or public_html.
5. Update config.php with the database host, database name, username and password supplied
   by your host. Hosting credentials are different from XAMPP's local defaults.
6. Visit the public URL assigned by your host on your smartphone.

SECURITY NOTES
- This is a starter learning project, not a production-ready school system.
- There is no admin login yet. Do not put real student data on a public link until you add
  authentication, authorization, CSRF protection, backups and HTTPS.
- Do not share your hosting database password publicly.
