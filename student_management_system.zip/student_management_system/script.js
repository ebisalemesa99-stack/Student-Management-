document.querySelectorAll('.delete-form').forEach(function(form){form.addEventListener('submit',function(event){if(!confirm('Are you sure you want to delete this student record?')) event.preventDefault();});});
const studentForm = document.getElementById('student-form');
if (studentForm) {
  studentForm.addEventListener('submit', function(event) {
    const name = studentForm.querySelector('[name="full_name"]');
    if (name && !name.value.trim()) {
      event.preventDefault();
      alert('Please enter the student full name.');
      name.focus();
    }
  });
}
