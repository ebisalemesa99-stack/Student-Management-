CREATE DATABASE IF NOT EXISTS student_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_management;

CREATE TABLE IF NOT EXISTS students (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  student_id VARCHAR(40) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  department VARCHAR(100) NOT NULL,
  year_of_study TINYINT UNSIGNED NOT NULL DEFAULT 1,
  email VARCHAR(160) NULL,
  phone VARCHAR(30) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_students_student_id (student_id),
  KEY idx_students_name (full_name),
  CONSTRAINT chk_year_of_study CHECK (year_of_study BETWEEN 1 AND 6)
);

-- Optional sample record. Remove the comment marks to insert it.
-- INSERT INTO students (student_id, full_name, department, year_of_study, email)
-- VALUES ('SE2026001', 'Example Student', 'Software Engineering', 2, 'student@example.com');
