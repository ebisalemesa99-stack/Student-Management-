<?php
require_once __DIR__ . '/config.php';
$errors = [];
$data = ['student_id'=>'','full_name'=>'','department'=>'','year_of_study'=>'1','email'=>'','phone'=>''];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($data as $key => $value) $data[$key] = trim($_POST[$key] ?? $value);
    if ($data['student_id'] === '') $errors[] = 'Student ID is required.';
    if ($data['full_name'] === '') $errors[] = 'Full name is required.';
    if ($data['department'] === '') $errors[] = 'Department is required.';
    if (!in_array($data['year_of_study'], ['1','2','3','4','5','6'], true)) $errors[] = 'Choose a valid year of study.';
    if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!$errors) {
        try {
            $stmt = $pdo->prepare('INSERT INTO students (student_id, full_name, department, year_of_study, email, phone) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute([$data['student_id'],$data['full_name'],$data['department'],$data['year_of_study'],$data['email'] ?: null,$data['phone'] ?: null]);
            header('Location: index.php?message=' . urlencode('Student added successfully.')); exit;
        } catch (PDOException $e) { $errors[] = 'That student ID may already exist. Check the ID and try again.'; }
    }
}
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Add student · StudentHub</title><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand brand-link" href="index.php"><span class="brand-mark">S</span><div><strong>StudentHub</strong><small>Student Management System</small></div></a><a class="btn secondary" href="index.php">← Back</a></header>
<main class="form-container"><p class="eyebrow">STUDENT RECORD</p><h1>Add a student</h1><p class="muted">Fill in the details below and save the record.</p>
<?php if ($errors): ?><div class="error-box"><?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?></div><?php endif; ?>
<form method="post" class="panel form-panel" id="student-form">
<label>Student ID <span>*</span><input name="student_id" required maxlength="40" value="<?= h($data['student_id']) ?>" placeholder="e.g. SE2026001"></label>
<label>Full name <span>*</span><input name="full_name" required maxlength="120" value="<?= h($data['full_name']) ?>" placeholder="Enter student's full name"></label>
<label>Department <span>*</span><input name="department" required maxlength="100" value="<?= h($data['department']) ?>" placeholder="e.g. Software Engineering"></label>
<label>Year of study <span>*</span><select name="year_of_study"><?php for($i=1;$i<=6;$i++): ?><option value="<?= $i ?>" <?= $data['year_of_study']==(string)$i?'selected':'' ?>>Year <?= $i ?></option><?php endfor; ?></select></label>
<label>Email <input type="email" name="email" maxlength="160" value="<?= h($data['email']) ?>" placeholder="student@example.com"></label>
<label>Phone <input name="phone" maxlength="30" value="<?= h($data['phone']) ?>" placeholder="Optional phone number"></label>
<div class="form-actions"><a class="btn secondary" href="index.php">Cancel</a><button class="btn primary" type="submit">Save student</button></div></form></main><script src="script.js"></script></body></html>